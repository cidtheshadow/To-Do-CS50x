import { Progress } from "@/components/ui/progress";
import { LEVEL_THRESHOLD } from "@shared/schema";
import { motion } from "framer-motion";

interface XPBarProps {
  experience: number;
}

export function XPBar({ experience }: XPBarProps) {
  const currentLevelXP = experience % LEVEL_THRESHOLD;
  const progress = (currentLevelXP / LEVEL_THRESHOLD) * 100;

  return (
    <div className="space-y-2">
      <div className="flex justify-between text-sm text-primary-foreground/80">
        <span>Experience Progress</span>
        <motion.span
          key={currentLevelXP}
          initial={{ scale: 1 }}
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ duration: 0.3 }}
        >
          {currentLevelXP}/{LEVEL_THRESHOLD} XP
        </motion.span>
      </div>
      <div className="relative">
        <div className="absolute inset-0 bg-primary/20 rounded-full blur-sm" />
        <Progress 
          value={progress} 
          className="h-3 relative" 
        />
      </div>
    </div>
  );
}