import { motion } from "framer-motion";
import { Crown } from "lucide-react";

interface LevelBadgeProps {
  level: number;
}

export function LevelBadge({ level }: LevelBadgeProps) {
  return (
    <motion.div
      className="relative group"
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
    >
      <div className="absolute inset-0 bg-primary/20 rounded-full blur-lg group-hover:bg-primary/30 transition-colors" />
      <div className="relative flex flex-col items-center justify-center w-20 h-20 bg-gradient-to-br from-primary/80 to-primary rounded-full border-4 border-primary-foreground/20">
        <Crown className="w-8 h-8 text-primary-foreground drop-shadow-glow" />
        <span className="text-xl font-bold text-primary-foreground drop-shadow-glow">
          {level}
        </span>
      </div>
    </motion.div>
  );
}