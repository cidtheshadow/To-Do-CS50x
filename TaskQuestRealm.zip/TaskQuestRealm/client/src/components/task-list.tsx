import { useQuery, useMutation } from "@tanstack/react-query";
import { Task, DIFFICULTY_XP } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { motion, AnimatePresence } from "framer-motion";
import { Trash2, Swords, Star, Target } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

const difficultyIcons = {
  easy: Star,
  medium: Swords,
  hard: Target,
};

export function TaskList() {
  const { toast } = useToast();
  const { data: tasks = [], isLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const completeMutation = useMutation({
    mutationFn: async (taskId: number) => {
      const res = await apiRequest("PATCH", `/api/tasks/${taskId}/complete`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/progress"] });
      toast({
        title: "Quest Completed!",
        description: "You gained experience points!",
        className: "bg-primary/10 border-primary",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (taskId: number) => {
      await apiRequest("DELETE", `/api/tasks/${taskId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
  });

  if (isLoading) {
    return <div className="p-6 text-center text-muted-foreground">Loading quests...</div>;
  }

  if (tasks.length === 0) {
    return (
      <div className="p-6 text-center text-muted-foreground">
        No quests available. Add some quests to begin your journey!
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
      <AnimatePresence>
        {tasks.map((task) => {
          const DifficultyIcon = difficultyIcons[task.difficulty as keyof typeof difficultyIcons];

          return (
            <motion.div
              key={task.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, x: -100 }}
              className="group"
            >
              <Card className="p-4 transition-all duration-300 hover:shadow-[0_0_15px_rgba(var(--primary),0.3)] border-primary/20">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="relative">
                      <div className="absolute inset-0 bg-primary/20 rounded-md blur group-hover:bg-primary/30 transition-colors" />
                      <Checkbox
                        checked={task.completed}
                        onCheckedChange={() => completeMutation.mutate(task.id)}
                        disabled={task.completed}
                        className="relative border-primary"
                      />
                    </div>
                    <div>
                      <p className={`text-lg ${task.completed ? "line-through text-muted-foreground" : "text-primary-foreground"}`}>
                        {task.title}
                      </p>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <DifficultyIcon className="w-4 h-4 text-primary" />
                        <span className="capitalize">{task.difficulty}</span>
                        <span>•</span>
                        <span>{DIFFICULTY_XP[task.difficulty as keyof typeof DIFFICULTY_XP]} XP</span>
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => deleteMutation.mutate(task.id)}
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </Card>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}