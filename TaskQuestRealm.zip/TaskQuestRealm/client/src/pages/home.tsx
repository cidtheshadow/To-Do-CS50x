import { TaskList } from "@/components/task-list";
import { TaskForm } from "@/components/task-form";
import { XPBar } from "@/components/xp-bar";
import { LevelBadge } from "@/components/level-badge";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@shared/schema";
import { Scroll, LogOut } from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

export default function Home() {
  const [, setLocation] = useLocation();
  const { data: progress, isLoading: progressLoading } = useQuery<Progress>({
    queryKey: ["/api/progress"],
  });

  const { data: auth } = useQuery({
    queryKey: ["/api/auth/me"],
  });

  const handleLogout = async () => {
    await apiRequest("POST", "/api/auth/logout");
    queryClient.clear();
    setLocation("/login");
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-8 bg-[radial-gradient(circle_at_center,rgba(55,23,23,0.2)_0%,rgba(0,0,0,0.5)_100%)]">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="flex items-center justify-between bg-black/30 p-6 rounded-lg backdrop-blur-sm border border-primary/20">
          <div className="flex items-center gap-4">
            <Scroll className="h-8 w-8 text-primary" />
            <div>
              <h1 className="text-4xl font-bold text-primary font-serif">Quest Log</h1>
              <p className="text-primary/80">Welcome, {auth?.username}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            {progressLoading ? (
              <Skeleton className="h-20 w-20 rounded-full" />
            ) : (
              <LevelBadge level={progress?.level || 1} />
            )}
            <Button 
              variant="ghost" 
              size="icon"
              onClick={handleLogout}
              className="text-primary hover:text-primary/80"
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {progressLoading ? (
          <Skeleton className="h-4 w-full" />
        ) : (
          <div className="bg-black/30 p-6 rounded-lg backdrop-blur-sm border border-primary/20">
            <XPBar experience={progress?.experience || 0} />
          </div>
        )}

        <div className="bg-black/30 p-6 rounded-lg backdrop-blur-sm border border-primary/20">
          <TaskForm />
        </div>

        <div className="bg-black/30 rounded-lg backdrop-blur-sm border border-primary/20">
          <TaskList />
        </div>
      </div>
    </div>
  );
}