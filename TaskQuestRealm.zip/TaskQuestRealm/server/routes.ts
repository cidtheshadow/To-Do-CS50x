import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertTaskSchema, insertPlayerSchema, DIFFICULTY_XP } from "@shared/schema";
import session from "express-session";
import memorystore from "memorystore";

const MemoryStore = memorystore(session);

declare module "express-session" {
  interface SessionData {
    playerId?: number;
    username?: string;
  }
}

export async function registerRoutes(app: Express) {
  // Setup session middleware
  app.use(
    session({
      store: new MemoryStore({
        checkPeriod: 86400000, // prune expired entries every 24h
      }),
      secret: "your-secret-key",
      resave: false,
      saveUninitialized: false,
      cookie: { secure: false }, // set to true if using https
    })
  );

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    const result = insertPlayerSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: "Invalid player data" });
    }

    try {
      const existingPlayer = await storage.getPlayerByUsername(result.data.username);
      if (existingPlayer) {
        return res.status(400).json({ error: "Username already taken" });
      }

      const player = await storage.createPlayer(result.data);
      req.session.playerId = player.id;
      req.session.username = player.username;
      res.json({ username: player.username });
    } catch (error) {
      res.status(500).json({ error: "Failed to create player" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    const result = insertPlayerSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: "Invalid credentials" });
    }

    try {
      const player = await storage.getPlayerByUsername(result.data.username);
      if (!player || player.password !== result.data.password) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      req.session.playerId = player.id;
      req.session.username = player.username;
      res.json({ username: player.username });
    } catch (error) {
      res.status(500).json({ error: "Failed to log in" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy(() => {
      res.status(200).send();
    });
  });

  app.get("/api/auth/me", (req, res) => {
    if (!req.session.username) {
      return res.status(401).json({ error: "Not authenticated" });
    }
    res.json({ username: req.session.username });
  });

  // Middleware to check if user is authenticated
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session.playerId) {
      return res.status(401).json({ error: "Not authenticated" });
    }
    next();
  };

  // Protected routes
  app.get("/api/tasks", requireAuth, async (req, res) => {
    const tasks = await storage.getTasks(req.session.playerId!);
    res.json(tasks);
  });

  app.post("/api/tasks", requireAuth, async (req, res) => {
    const result = insertTaskSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: "Invalid task data" });
    }

    const task = await storage.createTask(result.data, req.session.playerId!);
    res.json(task);
  });

  app.patch("/api/tasks/:id/complete", requireAuth, async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid task ID" });
    }

    try {
      const task = await storage.updateTask(id, true);
      const xp = DIFFICULTY_XP[task.difficulty as keyof typeof DIFFICULTY_XP];
      const progress = await storage.updateProgress(req.session.playerId!, xp);

      res.json({ task, progress });
    } catch (error) {
      res.status(404).json({ error: "Task not found" });
    }
  });

  app.delete("/api/tasks/:id", requireAuth, async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid task ID" });
    }

    try {
      await storage.deleteTask(id);
      res.status(204).send();
    } catch (error) {
      res.status(404).json({ error: "Task not found" });
    }
  });

  app.get("/api/progress", requireAuth, async (req, res) => {
    const progress = await storage.getProgress(req.session.playerId!);
    res.json(progress);
  });

  return createServer(app);
}