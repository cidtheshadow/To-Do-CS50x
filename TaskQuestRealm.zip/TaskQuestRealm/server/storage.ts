import { type Task, type InsertTask, type Progress, type Player, type InsertPlayer } from "@shared/schema";

export interface IStorage {
  // Player methods
  createPlayer(player: InsertPlayer): Promise<Player>;
  getPlayerByUsername(username: string): Promise<Player | undefined>;

  // Task methods
  getTasks(playerId: number): Promise<Task[]>;
  createTask(task: InsertTask, playerId: number): Promise<Task>;
  updateTask(id: number, completed: boolean): Promise<Task>;
  deleteTask(id: number): Promise<void>;

  // Progress methods
  getProgress(playerId: number): Promise<Progress>;
  updateProgress(playerId: number, xp: number): Promise<Progress>;
}

export class MemStorage implements IStorage {
  private players: Map<number, Player>;
  private tasks: Map<number, Task>;
  private progress: Map<number, Progress>;
  private currentId: number;

  constructor() {
    this.players = new Map();
    this.tasks = new Map();
    this.progress = new Map();
    this.currentId = 1;
  }

  async createPlayer(insertPlayer: InsertPlayer): Promise<Player> {
    const id = this.currentId++;
    const player: Player = { ...insertPlayer, id };
    this.players.set(id, player);

    // Initialize progress for new player
    this.progress.set(id, {
      id,
      level: 1,
      experience: 0,
      playerId: id,
    });

    return player;
  }

  async getPlayerByUsername(username: string): Promise<Player | undefined> {
    return Array.from(this.players.values()).find(
      (player) => player.username === username,
    );
  }

  async getTasks(playerId: number): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(
      (task) => task.playerId === playerId,
    );
  }

  async createTask(insertTask: InsertTask, playerId: number): Promise<Task> {
    const id = this.currentId++;
    const task: Task = { ...insertTask, id, completed: false, playerId };
    this.tasks.set(id, task);
    return task;
  }

  async updateTask(id: number, completed: boolean): Promise<Task> {
    const task = this.tasks.get(id);
    if (!task) throw new Error("Task not found");

    const updatedTask = { ...task, completed };
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }

  async deleteTask(id: number): Promise<void> {
    if (!this.tasks.has(id)) throw new Error("Task not found");
    this.tasks.delete(id);
  }

  async getProgress(playerId: number): Promise<Progress> {
    const progress = this.progress.get(playerId);
    if (!progress) throw new Error("Progress not found");
    return progress;
  }

  async updateProgress(playerId: number, xp: number): Promise<Progress> {
    const progress = await this.getProgress(playerId);
    const newXP = progress.experience + xp;
    const newLevel = Math.floor(newXP / 100) + 1;

    const updatedProgress = {
      ...progress,
      level: newLevel,
      experience: newXP,
    };

    this.progress.set(playerId, updatedProgress);
    return updatedProgress;
  }
}

export const storage = new MemStorage();