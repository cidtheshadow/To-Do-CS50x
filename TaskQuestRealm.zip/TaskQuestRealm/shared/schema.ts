import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const players = pgTable("players", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  completed: boolean("completed").notNull().default(false),
  difficulty: text("difficulty").notNull(), // easy, medium, hard
  playerId: integer("player_id").notNull(),
});

export const progress = pgTable("progress", {
  id: serial("id").primaryKey(),
  level: integer("level").notNull().default(1),
  experience: integer("experience").notNull().default(0),
  playerId: integer("player_id").notNull().unique(),
});

export const insertPlayerSchema = createInsertSchema(players).pick({
  username: true,
  password: true,
});

export const insertTaskSchema = createInsertSchema(tasks).pick({
  title: true,
  difficulty: true,
});

export const taskSchema = createInsertSchema(tasks);

export type InsertPlayer = z.infer<typeof insertPlayerSchema>;
export type Player = typeof players.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;
export type Progress = typeof progress.$inferSelect;

export const DIFFICULTY_XP = {
  easy: 10,
  medium: 25,
  hard: 50,
};

export const LEVEL_THRESHOLD = 100; // XP needed per level